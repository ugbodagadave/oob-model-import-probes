oob control, no weights
